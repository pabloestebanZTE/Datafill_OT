<?php

    defined('BASEPATH') OR exit('No direct script access allowed');

    class Dao_report_model extends CI_Model{

        public function __construct(){
            $this->load->model('data/configdb_model');
            $this->load->model('report_model');
        }

        
    }
?>
