<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>rondas</title>
</head>
<body>
	<form action="Welcome/roundTenis" method="post">
		ingrese el numero 
		<input type="text" name="txtnum"><br>
		
		<input type="submit"  value="ingresar">
	</form>





</body>
</html>